# Changelog

## 23-12-2022 
 - Added DCR Association for VM Insights DCR when deploying new Session Hosts

## 19-12-2022 
 - Added DCR Association when deploying new Session Hosts
 - Updated AzureRM module from 3.15 to 3.34

## 16-12-2022 
  - Fixed Log Analytics Agent deployment issue when deploying multiple session hosts
  - Added installation of Azure Monitoring Agent
  - Added pathcheck in renstate.ps1

## 12-12-2022 
 - Added missing d-avdlaw-secret.tf
 - Made keyvault properties dynamic using variable
 - Added additional deployment wrapper scripts
 - Added CHANGELOG.md