# Changelog

## 23-12-2022
 - Added DCR for AVD Session Hosts monitoring

## 25-11-2022
 - Added AVD Insights needed performance counters 
 - Added AVD Insights needed event logs

## 21-11-2022
 - Added MMA Deployment on Session Hosts for AVD Insights (Still MMA because AVD Insights does not support AMA yet)
 
## 09-11-2022
 - Update naming of AVD environment resources

## 01-11-2022
 - Changed the method used to enable diagnostics logging to the log analytics workspace
 - Added spokename variable to resource names
 - Added instance variable to resource names
 - Added location_short variable to resource names
