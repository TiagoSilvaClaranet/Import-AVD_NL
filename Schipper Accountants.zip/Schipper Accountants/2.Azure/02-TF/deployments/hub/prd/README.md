# This deployment deploys the platform landing zone containing the following:
- Connectivity
- Management
- Identity
- Shared Services