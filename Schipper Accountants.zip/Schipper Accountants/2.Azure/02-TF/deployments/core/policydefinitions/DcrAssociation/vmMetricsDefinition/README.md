Customized policy definition based on 'Configure Windows Virtual Machines to be associated with a Data Collection Rule or a Data Collection Endpoint') which also deploys to SQL *-2022 servers so the DCR 'dcr-default-windowsvm-monitoring' is assigned properly

Added SQL Server (*-WS2022,*-WS2022-BYOL,*-WS2019,*-WS2019-BYOL)
Added Windows 11
Added condition not to apply when a virtual machine has a tag named 'Monitoring Disabled'